// JavaScript Document
// Try jQuery interpreter plugin

(function( $ ){

	$.fn.interpreter = function( type ) {  

    	return this.each(function() {

      		var $this = $(this);

    	});

	};
	
})( jQuery );